import Hljs from 'highlight.js'

export default Hljs
