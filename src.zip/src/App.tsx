import React, { useEffect, useState } from "react";
import AV from "leancloud-storage";
import { Col, Layout, Row, Menu, Affix, Button } from "antd";
import {
  TagsOutlined,
  ProfileOutlined,
  HomeOutlined,
  ReadOutlined,
  ControlOutlined,
  SettingOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { init, q2o } from "./lib";
import InfoCard from "./components/InfoCard";
import { Link, useLocation, useNavigate, useRoutes } from "react-router-dom";
import routes from "./routes";
import { subscribe, unsubscribe, publish } from "pubsub-js";

const { Header, Footer, Content } = Layout;

const _items = new Array(3).fill(null).map((_, index) => ({
  key: index + 1,
  label: `nav ${index + 1}`,
}));

const items = [
  {
    key: "1",
    label: <Link to="/home">首页</Link>,
    icon: <HomeOutlined />,
  },
  {
    key: "2",
    label: <Link to="/tag">标签</Link>,
    icon: <TagsOutlined />,
  },
  {
    key: "3",
    label: <Link to="/article">归档</Link>,
    icon: <ProfileOutlined />,
  },
  {
    key: "4",
    label: "阅读",
    icon: <ReadOutlined />,
  },
];

const adminItems = [
  {
    key: "5",
    label: <Link to="/adminHome">控制台</Link>,
    icon: <ControlOutlined />,
  },
  {
    key: "6",
    label: <Link to="/modifyArticle">文章管理</Link>,
    icon: <EditOutlined />,
  },
  {
    key: "7",
    label: <Link to="/modifyTags">标签管理</Link>,
    icon: <TagsOutlined />,
  },
  {
    key: "8",
    label: <Link to="/settings">设置</Link>,
    icon: <SettingOutlined />,
  },
];

new AV.Object("Init").save().then((_) =>
  new AV.Query("Init").find().then((res) => {
    console.log(res.length);
    if (res.length <= 1) init();
    else q2o(res[0]).destroy();
  })
);

let authenticated = false;
function App() {
  const route = useRoutes(routes);
  let blogMeta: AV.Object[] = [];
  let tags: AV.Object[] = [];
  let settings: AV.Object;
  const navigate = useNavigate();
  const location = useLocation();

  function updateBlogMeta() {
    new AV.Query("BlogMeta").find().then((res) => {
      blogMeta = res.map((q) => q2o(q));
      localStorage.setItem(
        "blogMeta",
        JSON.stringify(blogMeta.map((o) => o.toFullJSON()))
      );
    });
  }
  function updateTags() {
    new AV.Query("Tags").find().then((res) => {
      tags = res.map((q) => q2o(q));
      localStorage.setItem("tags", JSON.stringify(tags));
    });
  }
  function updateSettings() {
    new AV.Query("Settings")
      .equalTo("owner", "admin")
      .find()
      .then((res) => {
        settings = q2o(res[0]);
        localStorage.setItem("settings", JSON.stringify(settings));
      });
  }
  useEffect(() => {
    updateBlogMeta();
    updateSettings();
    updateTags();
    subscribe("auth", () => {
      authenticated = true;
      navigate("/adminHome");
    });
    subscribe("isAuthed", () => publish("setAuth", authenticated));
    return () => {
      unsubscribe("auth");
    };
  }, []);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [useAdminMenu, setUseAdminMenu] = useState<boolean>(false);
  useEffect(() => {
    if (
      location.pathname.includes("/adminHome") ||
      location.pathname.includes("/modify") ||
      location.pathname.includes("/settings")
    ) {
      setUseAdminMenu(true);
      if (location.pathname.includes("/modifyArticle")) setSelectedKeys(["6"]);
      else if (location.pathname.includes("/modifyTags"))
        setSelectedKeys(["7"]);
      else if (location.pathname.includes("/settings")) setSelectedKeys(["8"]);
      else setSelectedKeys(["5"]);
    } else {
      setUseAdminMenu(false);
      if (location.search.length > 0) {
        if (location.pathname.includes("/article")) setSelectedKeys(["4"]);
        else setSelectedKeys(["2"]);
      } else {
        if (location.pathname.includes("/tag")) setSelectedKeys(["2"]);
        else if (location.pathname.includes("/article")) setSelectedKeys(["3"]);
        else setSelectedKeys(["1"]);
      }
    }
  }, [location]);

  return (
    <Layout
      className="App"
      style={{ backgroundColor: "#fafafa", width: "100vw", height: "100vh" }}
    >
      <Header
        style={{
          boxShadow: "0 5px 20px 0px rgba(0,0,0,0.04)",
          marginBottom: "15px",
        }}
      >
        <Button
          type="primary"
          onClick={() => navigate("/authentication")}
          style={{ float: "right" }}
        >
          控制台
        </Button>
        <Menu
          theme="light"
          mode="horizontal"
          defaultSelectedKeys={["2"]}
          items={_items}
          style={{
            flex: 1,
            minWidth: 0,
            float: "right",
          }}
        />
      </Header>
      <Content>
        <Row>
          <Col span={2} />
          <Col span={12}>{route}</Col>
          <Col span={1} />
          <Col span={7}>
            <Affix offsetTop={30}>
              <InfoCard>
                <h3>公告</h3>
                <div style={{ textAlign: "center" }}>Hello, World!</div>
              </InfoCard>
              <InfoCard>
                {useAdminMenu ? (
                  <Menu
                    mode="inline"
                    theme="light"
                    items={adminItems}
                    defaultSelectedKeys={["5"]}
                    selectedKeys={selectedKeys}
                    selectable={false}
                  />
                ) : (
                  <Menu
                    mode="inline"
                    theme="light"
                    items={items}
                    defaultSelectedKeys={["1"]}
                    selectedKeys={selectedKeys}
                    selectable={false}
                  />
                )}
              </InfoCard>
            </Affix>
          </Col>
        </Row>
      </Content>
    </Layout>
  );
}

export default App;
