import React, { useEffect, useState } from "react";
import InfoCard from "../components/InfoCard";
import AV from "leancloud-storage";
import { MDParse } from "../lib";

export default function Home() {
  const [responses, setResponses] = useState<AV.Queriable[]>([]);

  useEffect(() => {
    (async () => {
      setResponses(await new AV.Query("BlogContent").limit(5).find());
    })();
  }, []);

  return (
    <div>
      <InfoCard>
        <strong>首页</strong>
      </InfoCard>
      {responses.map((q) => (
        <InfoCard key={Math.random()}>
          <h1>{q.get("title")}</h1>
          {MDParse(q.get("content"))}
        </InfoCard>
      ))}
    </div>
  );
}
