import React, { useEffect, useState } from "react";
import { List } from "antd";
import InfoCard from "../components/InfoCard";
import { Link, useSearchParams } from "react-router-dom";

export default function Tag() {
  let [tags, setTags] = useState<any[]>([]);
  let [blogMeta, setBlogMeta] = useState<any[]>([]);
  let [search] = useSearchParams();
  let name = search.get("name");
  useEffect(() => {
    setTags(JSON.parse(localStorage.getItem("tags") as string));
    setBlogMeta(
      JSON.parse(localStorage.getItem("blogMeta") as string) as any[]
    );
  }, []);

  return (
    <div>
      <InfoCard>
        {name && tags.length > 0 ? (
          <List
            header={<div>{name}</div>}
            dataSource={tags.find((o) => o.name === name).ids}
            renderItem={(item: string) => (
              <List.Item>
                <Link to={"/article?id=" + item}>
                  {blogMeta.find((m) => m.id === item)?.title}
                </Link>
              </List.Item>
            )}
          />
        ) : (
          <List
            header={<div>标签总览</div>}
            dataSource={tags}
            renderItem={(item) => (
              <List.Item>
                <Link to={"/tag?name=" + item.name}>{item.name}</Link>
              </List.Item>
            )}
          />
        )}
      </InfoCard>
    </div>
  );
}
