// import React, { useState, useEffect } from "react";
import { useSearchParams, Link, useLocation } from "react-router-dom";
import AV from "leancloud-storage";
import { MDParse, q2o, ArchiveArticle } from "../lib";
import React, { useEffect, useState } from "react";
import InfoCard from "../components/InfoCard";

const Article = () => {
  const location = useLocation();
  const [search] = useSearchParams();
  let [blogContent, setBlogContent] = useState<AV.Object>();
  let blogMeta = [];
  let [articles, setArticles] = useState<ArchiveArticle[][]>([[]]);
  const id = search.get("id");
  useEffect(()=>{
    if (id) {
      new AV.Query("BlogContent")
        .equalTo("id", id)
        .find()
        .then((res) => {
          setBlogContent(q2o(res[0]));
        });
    } else {
      blogMeta = JSON.parse(localStorage.getItem("blogMeta") as string);
      articles = [];
      let y = Infinity;
      for (let i in blogMeta) {
        const meta = blogMeta[i];
        const y2 = new Date(meta.createdAt).getFullYear();
        if (y2 < y) {
          articles.push([
            new ArchiveArticle(meta.title, meta.id, new Date(meta.createdAt)),
          ]);
          y = y2;
        } else {
          articles[articles.length - 1].push(
            new ArchiveArticle(meta.title, meta.id, new Date(meta.createdAt))
          );
        }
      }
      setArticles(articles);
    }
  }, [location])
  return (
    <div>
      <div>
        {id ? (
          <InfoCard>
            <h1 style={{ textAlign: "center" }}>{blogContent?.get("title")}</h1>
            {MDParse(blogContent?.get("content"))}
          </InfoCard>
        ) : articles[0].length > 0 ? (
          articles.map((arr) => (
            <InfoCard>
              <strong>{arr[0].createdAt.getFullYear()}</strong>
              {arr.map((article) => (
                <p>
                  <Link to={"/article?id=" + article.id}>{article.title}</Link>
                  {"   "}
                  <i>{article.id}</i>
                </p>
              ))}
            </InfoCard>
          ))
        ) : (
          <></>
        )}
      </div>
    </div>
  );
};

export default Article;
