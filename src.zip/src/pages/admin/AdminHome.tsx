import { message } from "antd";
import { publish, subscribe, unsubscribe } from "pubsub-js";
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import InfoCard from "../../components/InfoCard";

let verified = false;
export default function AdminHome() {
  const navigate = useNavigate();
  useEffect(() => {
    subscribe("setAuth", (_, data) => {
      if (!data) {
        message.error("您需要登录");
        verified = true;
        navigate("/authentication");
      }
    });
    if (!verified) {
      publish("isAuthed");
    }
    return () => {
      unsubscribe("setAuth");
      verified = false;
    };
  }, []);

  return (
    <div>
      <InfoCard>
        <strong>Leanite 控制台，V0.1.0</strong>
      </InfoCard>
    </div>
  );
}
